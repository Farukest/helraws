#!/bin/bash

sudo pgrep lora_pkt_+ > /var/dashboard/statuses/packet-forwarder
